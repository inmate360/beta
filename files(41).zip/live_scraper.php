<?php
/**
 * Inmate360 - Live Scraper for Active Inmates
 * Fetches and parses the main active inmates list from wsj201r.pgm
 */

require_once 'config.php';

function fetch_live_inmates() {
    $url = 'http://weba.claytoncountyga.gov/sjiinqcgi-bin/wsj201r.pgm';
    $log_prefix = '[live_scraper]';

    try {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => defined('TIMEOUT') ? TIMEOUT : 20,
            CURLOPT_USERAGENT      => defined('USER_AGENT') ? USER_AGENT : 'Inmate360/1.0',
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
        ]);

        $html = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlErr = curl_error($ch);
        curl_close($ch);

        if ($curlErr) {
            error_log("$log_prefix cURL Error: $curlErr");
            return [];
        }
        if ($httpCode !== 200) {
            error_log("$log_prefix HTTP Error: $httpCode");
            return [];
        }
        if (!$html) {
            error_log("$log_prefix Empty response from server.");
            return [];
        }

        libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $dom->loadHTML($html);
        libxml_clear_errors();
        $xpath = new DOMXPath($dom);

        $inmates = [];
        $rows = $xpath->query('//table/tr');

        foreach ($rows as $row) {
            $cells = $xpath->query('.//td', $row);
            if ($cells->length >= 6) {
                // Expected format: Docket, Name, LE#, Age, Charge, Bond
                $docketLink = $xpath->query('.//a', $cells->item(0))->item(0);
                $docketNumber = $docketLink ? trim($docketLink->textContent) : trim($cells->item(0)->textContent);

                if (empty($docketNumber)) continue;

                $inmate = [
                    'id' => $docketNumber, // Use docket as a unique ID
                    'inmate_id' => $docketNumber,
                    'docket_number' => $docketNumber,
                    'name' => trim($cells->item(1)->textContent),
                    'le_number' => trim($cells->item(2)->textContent),
                    'age' => trim($cells->item(3)->textContent),
                    'all_charges' => trim($cells->item(4)->textContent),
                    'bond_amount' => trim($cells->item(5)->textContent),
                    'booking_date' => date('Y-m-d H:i:s'), // Placeholder, not available on this page
                    'in_jail' => 1,
                    'charge_count' => 1, // Placeholder
                ];
                
                $inmates[] = $inmate;
            }
        }
        
        return $inmates;

    } catch (Exception $e) {
        error_log("$log_prefix Exception: " . $e->getMessage());
        return [];
    }
}