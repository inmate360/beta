<?php
/**
 * Inmate360 Configuration File
 * Clayton County Jail & Court Analytics Platform
 */

// Database Configuration
define('DB_PATH', __DIR__ . '/jail_data.db');
define('DB_BACKUP_PATH', __DIR__ . '/backups');
define('DB_BACKUP_RETENTION_DAYS', 30);

// Check if PDO SQLite driver is available
function checkPDOSQLite() {
    if (!extension_loaded('pdo_sqlite')) {
        echo "ERROR: PDO SQLite driver not found!\n\n";
        echo "Please install the SQLite extension:\n";
        echo "Ubuntu/Debian: sudo apt-get install php-sqlite3\n";
        echo "macOS: brew install php\n";
        echo "Windows: Enable extension=pdo_sqlite in php.ini\n\n";

        echo "Available PDO drivers:\n";
        print_r(PDO::getAvailableDrivers());
        echo "\n";

        return false;
    }
    return true;
}

// Jail Scraper Configuration - Multiple URLs
// UPDATED: Now includes Active Inmates (all time) + 31 days + 48 hours docket books
define('SCRAPE_URLS', [
    'Active_Inmates_All_Time' => 'https://weba.claytoncountyga.gov/sjiinqcgi-bin/wsj201r.pgm',
    '31_Day_Docket' => 'https://weba.claytoncountyga.gov/sjiinqcgi-bin/wsj210r.pgm?days=31&rtype=F',
    '48_Hour_Docket' => 'https://weba.claytoncountyga.gov/sjiinqcgi-bin/wsj210r.pgm?days=02&rtype=F'
]);

// Court Scraper Configuration
define('COURT_SCRAPE_BASE_URL', 'https://weba.claytoncountyga.gov/casinqcgi-bin/wci201r.pgm?ctt=A&dvt=C&cyr=2024&ctp=WA&csq=78533&lname=TATUM&fname=TESSA&mname=ELIZABETH&sname=&pname=&rtype=P,');

// Inmate Detail Scraper Configuration
define('INMATE_DETAIL_BASE_URL', 'https://weba.claytoncountyga.gov/sjiinqcgi-bin/wsj100r.pgm');

// Scraper Timing Configuration
define('SCRAPE_INTERVAL', 3600); // 1 hour in seconds
define('SCRAPE_DURATION', 172800); // 48 hours in seconds
define('USER_AGENT', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
define('TIMEOUT', 30);
define('MAX_RETRIES', 3);
define('RETRY_DELAY', 5); // seconds

// Site Configuration
define('SITE_URL', 'http://inmate360.com:8000'); // Change this to your actual domain
define('SITE_NAME', 'Inmate360');
define('SITE_DESCRIPTION', 'Unified Jail & Court Analytics Platform - Clayton County');
define('SITE_VERSION', '1.0.0');

// Logging Configuration
define('LOG_FILE', __DIR__ . '/scraper.log');
define('LOG_DIR', __DIR__ . '/logs');
define('LOG_LEVEL', 'INFO'); // DEBUG, INFO, WARNING, ERROR
define('LOG_MAX_SIZE', 10 * 1024 * 1024); // 10MB
define('LOG_ROTATION_COUNT', 5);

// Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', LOG_FILE);

// Timezone
date_default_timezone_set('America/New_York');

// Admin Configuration
define('ADMIN_PASSWORD', 'admin123'); // Change this!
define('REQUIRE_INVITE', true);
define('ADMIN_EMAIL', 'admin@inmate360.com');

// Security Configuration
define('SESSION_TIMEOUT', 3600); // 1 hour in seconds
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutes

// Pagination
define('DEFAULT_PER_PAGE', 30);
define('MAX_PER_PAGE', 100);

// Cross-linking Configuration
define('ENABLE_CROSS_LINKING', true);
define('AUTO_LINK_SIMILARITY_THRESHOLD', 70); // Percentage for name matching
define('MANUAL_LINK_EXPIRY', 30); // Days for manual link verification

// Invite System Configuration
define('DEFAULT_INVITE_MAX_USES', 100);
define('DEFAULT_INVITE_EXPIRY_DAYS', 30);
define('INVITE_CODE_LENGTH', 12);

// Cache Configuration
define('CACHE_ENABLED', true);
define('CACHE_TTL', 3600); // 1 hour
define('CACHE_DIR', __DIR__ . '/cache');

// Email Configuration (for future use)
define('SMTP_HOST', 'localhost');
define('SMTP_PORT', 587);
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('SMTP_ENCRYPTION', 'tls');
define('FROM_EMAIL', 'noreply@inmate360.com');
define('FROM_NAME', 'Inmate360 System');

// API Configuration (for future use)
define('API_ENABLED', false);
define('API_KEY', '');
define('API_RATE_LIMIT', 100); // requests per hour

// Maintenance Configuration
define('MAINTENANCE_MODE', false);
define('MAINTENANCE_MESSAGE', 'System is currently under maintenance. Please check back later.');

// Performance Configuration
define('QUERY_TIMEOUT', 30); // seconds
define('MEMORY_LIMIT', '256M');
define('MAX_EXECUTION_TIME', 300); // 5 minutes

// Development Configuration
define('DEBUG_MODE', false);
define('SHOW_SQL_QUERIES', false);
define('PROFILING_ENABLED', false);

// Case Detail Scraper Configuration
define('CASE_DETAIL_CACHE_HOURS', 24); // Cache case details for 24 hours
define('CASE_DETAIL_MAX_RETRIES', 2);
define('CASE_DETAIL_RETRY_DELAY', 3); // seconds between retries
?>