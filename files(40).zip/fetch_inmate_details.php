<?php
/**
 * Endpoint: fetch_inmate_details.php
 * Fetches inmate detail page from Clayton County (wsj205r.pgm?dkt=...&le=...)
 * Parses details, updates DB (inmates, charges, inmate_detail_urls, inmate_case_details),
 * and returns JSON payload for client-side modal population.
 */

require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$dkt = $_POST['dkt'] ?? '';
$le  = $_POST['le']  ?? '';

// Basic validation
if (empty($dkt)) {
    echo json_encode(['success' => false, 'message' => 'Missing docket (dkt)']);
    exit;
}

// Build remote URL
$remote = 'https://weba.claytoncountyga.gov/sjiinqcgi-bin/wsj205r.pgm?dkt=' . urlencode($dkt) . '&le=' . urlencode($le);

try {
    // Fetch remote page
    $ch = curl_init($remote);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => TIMEOUT,
        CURLOPT_USERAGENT => USER_AGENT,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
    ]);
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr = curl_error($ch);
    curl_close($ch);

    if ($curlErr) {
        echo json_encode(['success' => false, 'message' => 'cURL error: ' . $curlErr]);
        exit;
    }
    if ($httpCode !== 200 || !$html) {
        echo json_encode(['success' => false, 'message' => "Remote returned HTTP $httpCode"]);
        exit;
    }

    // Parse HTML for key/value pairs
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML($html);
    libxml_clear_errors();
    $xpath = new DOMXPath($dom);

    $details = [
        'inmate_id' => $dkt,
        'le_number' => $le,
        'name' => null,
        'age' => null,
        'sex' => null,
        'race' => null,
        'height' => null,
        'weight' => null,
        'booking_date' => null,
        'release_date' => null,
        'bond_amount' => null,
        'charges' => []
    ];

    // Attempt to find label/value rows: iterate all table rows and collect pairs
    $rows = $xpath->query('//tr');
    foreach ($rows as $row) {
        $cells = $xpath->query('.//td|.//th', $row);
        if ($cells->length === 2) {
            $label = trim($cells->item(0)->textContent);
            $value = trim($cells->item(1)->textContent);
            $lk = strtolower(preg_replace('/[^a-z0-9]/', '_', $label));

            if (stripos($label, 'name') !== false && !$details['name']) {
                $details['name'] = $value;
            } elseif (preg_match('/age/i', $label) && !$details['age']) {
                $details['age'] = $value;
            } elseif (preg_match('/sex|gender/i', $label)) {
                $details['sex'] = $value;
            } elseif (preg_match('/race/i', $label)) {
                $details['race'] = $value;
            } elseif (preg_match('/height/i', $label)) {
                $details['height'] = $value;
            } elseif (preg_match('/weight/i', $label)) {
                $details['weight'] = $value;
            } elseif (preg_match('/booking date|booking_date|booked/i', $label)) {
                $details['booking_date'] = $value;
            } elseif (preg_match('/release date|release_date|released/i', $label)) {
                $details['release_date'] = $value;
            } elseif (preg_match('/bond/i', $label) && !$details['bond_amount']) {
                $details['bond_amount'] = $value;
            } elseif (preg_match('/charge|offense/i', $label)) {
                // Sometimes multiple charges may appear as CSV in value
                $candidates = array_filter(array_map('trim', preg_split('/;|,|\n/',$value)));
                foreach ($candidates as $c) {
                    if (!empty($c)) $details['charges'][] = $c;
                }
            }
        }
    }

    // Fallback parsing: try to extract the name from <title> or headers
    if (empty($details['name'])) {
        $title = $xpath->query('//title')->item(0);
        if ($title) {
            $t = trim($title->textContent);
            // use heuristics: title often contains name
            if (strlen($t) < 200) $details['name'] = $t;
        }
    }

    // Additional text based fallback: search page text for "Charge" lines
    $bodyText = '';
    $body = $xpath->query('//body')->item(0);
    if ($body) {
        $bodyText = $body->textContent ?? '';
    }
    $bodyText = preg_replace('/\s+/', ' ', $bodyText);

    // Extract charges by regex if none found
    if (empty($details['charges'])) {
        if (preg_match_all('/(?:Charge|Offense|CHARGE|OFFENSE)\s*[:\-\s]\s*(.+?)(?:\||\n|$)/i', $bodyText, $m)) {
            foreach ($m[1] as $c) {
                $c = trim($c);
                if ($c) $details['charges'][] = $c;
            }
        }
    }

    // Normalize bond: try to find $amount
    if (empty($details['bond_amount'])) {
        if (preg_match('/\$([0-9\.,]+)/', $bodyText, $m)) {
            $details['bond_amount'] = '$' . str_replace(',', '', $m[1]);
        }
    }

    // Save into DB
    $db = new PDO('sqlite:' . DB_PATH);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Update or insert inmate row (match by inmate_id or docket_number)
    $stmt = $db->prepare("
        SELECT id FROM inmates WHERE inmate_id = ? OR docket_number = ? LIMIT 1
    ");
    $stmt->execute([$dkt, $dkt]);
    $existingId = $stmt->fetchColumn();

    if ($existingId) {
        $updateStmt = $db->prepare("
            UPDATE inmates SET
                name = COALESCE(?, name),
                age = COALESCE(?, age),
                sex = COALESCE(?, sex),
                race = COALESCE(?, race),
                height = COALESCE(?, height),
                weight = COALESCE(?, weight),
                booking_date = COALESCE(?, booking_date),
                release_date = COALESCE(?, release_date),
                bond_amount = COALESCE(?, bond_amount),
                le_number = COALESCE(?, le_number),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $updateStmt->execute([
            $details['name'],
            $details['age'],
            $details['sex'],
            $details['race'],
            $details['height'],
            $details['weight'],
            $details['booking_date'],
            $details['release_date'],
            $details['bond_amount'],
            $details['le_number'] ?: null,
            $existingId
        ]);
        $inmateDbId = $existingId;
    } else {
        // create minimal record
        $insertStmt = $db->prepare("
            INSERT INTO inmates (
                docket_number, inmate_id, name, age, sex, race,
                height, weight, booking_date, release_date, bond_amount, le_number, in_jail, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)
        ");
        $insertStmt->execute([
            $dkt,
            $dkt,
            $details['name'] ?? null,
            $details['age'] ?? null,
            $details['sex'] ?? null,
            $details['race'] ?? null,
            $details['height'] ?? null,
            $details['weight'] ?? null,
            $details['booking_date'] ?? null,
            $details['release_date'] ?? null,
            $details['bond_amount'] ?? null,
            $details['le_number'] ?? null
        ]);
        $inmateDbId = $db->lastInsertId();
    }

    // Save charges into charges table (avoid duplicates by simple containment)
    if (!empty($details['charges'])) {
        $existingChargesStmt = $db->prepare("SELECT charge_description FROM charges WHERE inmate_id = ?");
        $existingChargesStmt->execute([$dkt]);
        $existingCharges = $existingChargesStmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($details['charges'] as $chargeText) {
            // simple dedupe
            $found = false;
            foreach ($existingCharges as $ec) {
                if (stripos($ec, $chargeText) !== false || stripos($chargeText, $ec) !== false) {
                    $found = true;
                    break;
                }
            }
            if (!$found) {
                $insertCharge = $db->prepare("INSERT INTO charges (inmate_id, charge_description, charge_type, created_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)");
                // simple charge type detection
                $chargeType = 'Unknown';
                if (stripos($chargeText, 'FELONY') !== false || stripos($chargeText, 'AGGRAVATED') !== false) {
                    $chargeType = 'Felony';
                } elseif (stripos($chargeText, 'MISDEMEANOR') !== false) {
                    $chargeType = 'Misdemeanor';
                }
                $insertCharge->execute([$dkt, $chargeText, $chargeType]);
            }
        }
    }

    // Update inmate_detail_urls scraped flag if exists
    try {
        $upd = $db->prepare("UPDATE inmate_detail_urls SET scraped = 1, last_scrape_attempt = CURRENT_TIMESTAMP WHERE inmate_id = ?");
        $upd->execute([$dkt]);
    } catch (Exception $e) {
        // ignore
    }

    // Optionally save to inmate_case_details (if schema present)
    try {
        $check = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='inmate_case_details'")->fetchColumn();
        if ($check) {
            $charges_json = json_encode(array_map(function($c){ return ['description'=>$c]; }, $details['charges']));
            $stmtCd = $db->prepare("
                INSERT INTO inmate_case_details (inmate_id, docket_number, disposition, sentence, charges_json, court_dates_json, bonds_json, scrape_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
                ON CONFLICT(inmate_id, docket_number) DO UPDATE SET
                    disposition = COALESCE(excluded.disposition, disposition),
                    sentence = COALESCE(excluded.sentence, sentence),
                    charges_json = COALESCE(excluded.charges_json, charges_json),
                    last_updated = CURRENT_TIMESTAMP
            ");
            $stmtCd->execute([
                $dkt,
                $dkt,
                null,
                null,
                $charges_json,
                json_encode([]),
                json_encode([['amount' => $details['bond_amount']]])
            ]);
        }
    } catch (Exception $e) {
        // ignore if table missing or other errors
    }

    // Return parsed details
    echo json_encode(['success' => true, 'details' => $details, 'message' => 'Fetched and saved details']);
    exit;

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
}
?>